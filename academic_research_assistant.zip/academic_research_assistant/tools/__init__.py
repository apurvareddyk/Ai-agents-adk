"""Tools for the Academic Research Assistant Agent."""
